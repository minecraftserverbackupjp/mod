package gvclib.render;

import net.minecraft.client.model.ModelBase;

public class ModelBase_Non extends ModelBase {

	public ModelBase_Non() {
		
	}
	
}
